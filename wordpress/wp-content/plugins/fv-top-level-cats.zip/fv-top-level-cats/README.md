fv-top-level-cats
=================

This is a fix of Top Level Categories plugin for Wordpress 3.1. and above.
=======
Removes the prefix from the URL for a category. For instance, if your old category link was &lt;code>/category/catname&lt;/code> it will now be &lt;code>/catname&lt;/code>
